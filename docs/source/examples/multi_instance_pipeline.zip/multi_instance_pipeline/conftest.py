import logging
import os
from pydiverse.common.util.structlog import setup_logging

log_level = logging.INFO if not os.environ.get("DEBUG", "") else logging.DEBUG
setup_logging(log_level=log_level)
